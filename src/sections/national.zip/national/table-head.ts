// NATIONAL SECCIÓN — preparado para Firebase
export const NATIONAL_TABLE_HEAD = [
  { id: 'name', label: 'Nombre' },
  { id: 'position', label: 'Posición Nacional' },
  { id: 'assignedRegion', label: 'Región Asignada' },
];

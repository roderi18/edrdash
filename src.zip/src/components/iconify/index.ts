export * from './classes';

export * from './iconify';

export * from './register-icons';
